<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <title>Daftar Pesanan</title>
</head>
<body>
    <div class="container mt-5">
        <h1>Daftar Pesanan</h1>
        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <div class="mb-4">
            <h4>Total Pemesanan: <?php echo e($totalOrders); ?></h4>
            <h4>Total Jumlah Barang: <?php echo e($totalQuantity); ?></h4>
            <h4>Total Harga: Rp <?php echo e(number_format($totalPrice, 2, ',', '.')); ?></h4>
        </div>

        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nama Pembeli</th>
                    <th>Produk</th>
                    <th>Harga Satuan</th>
                    <th>Jumlah</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($order->id); ?></td>
                        <td><?php echo e($order->customer_name); ?></td>
                        <td><?php echo e($order->product->name); ?></td>
                        <td>Rp <?php echo e(number_format($order->product->price, 2, ',', '.')); ?></td>
                        <td><?php echo e($order->quantity); ?></td>
                        <td><?php echo e($order->status); ?></td>
                        <td>
                            <form action="<?php echo e(route('orders.destroy', $order->id)); ?>" method="POST" style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger" onclick="return confirm('Apakah Anda yakin ingin membatalkan pesanan ini?')">Batalkan</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <a href="<?php echo e(route('products.index')); ?>" class="btn btn-secondary">Kembali ke Menu</a>
    </div>
</body>
</html>
<?php /**PATH D:\coding\tubes\TUBES_CHICKENSTEAKPAKTEJO_KELOMPOK1_PAW\resources\views/orders/index.blade.php ENDPATH**/ ?>